﻿using System.Windows;
using AdventureClient.BehavioralInterfaces;
using AdventureClient.ObserverInterfaces;
using System.Collections;
using System.Data.SqlClient;
using System.Data;
using Excel = Microsoft.Office.Interop.Excel;
//see if system.window has a box that can grab field entries
namespace AdventureClient.ComboActions
{
    class WorkOrderReport : ExcelReportable, MessageBoxPreviewable, Subject
    {
        private ArrayList observers;
        public string rownumbers;
        string connectionstring;
        public WorkOrderReport(string rownumbers)
        {
            this.rownumbers = "TOP" +"("+rownumbers+") ";
            connectionstring = @"Server=DESKTOP-270VR6H;Database=AdventureWorks2017;Trusted_Connection=Yes;";
            observers = new ArrayList();
        }

        public void messagePreview()
        {
            SqlConnection connection = new SqlConnection(this.connectionstring);
            string querylogic = "SELECT " + this.rownumbers + "P.[Name] AS [Item Name], Sum(OrderQty) AS AmountOrdered, SUM(P.ListPrice) AS OrderRevenue FROM AdventureWorks2017.Production.WorkOrder WO JOIN AdventureWorks2017.Production.Product P ON WO.ProductID = P.ProductID GROUP BY [Name]";
            string queryOutput = "";
            connection.Open();
            SqlCommand cmd = new SqlCommand(querylogic, connection);
            SqlDataReader reader = cmd.ExecuteReader();
            var dataTable = new DataTable();
            while (reader.Read())
            {
                queryOutput = queryOutput + reader.GetValue(0) + '-' + reader.GetValue(1) + '\n';
            }
            MessageBox.Show(queryOutput);
        }

        public void generateExcelReport()
        {
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            xlApp.Visible = true;
            Excel.Workbook xlWorkBook = xlApp.Workbooks.Add();
            Excel.Worksheet xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
            //xlWorkSheet.Cells[1, 1] = "ID";
            SqlConnection connection = new SqlConnection(this.connectionstring);
            string querylogic = "SELECT P.[Name] AS [Item Name], Sum(OrderQty) AS AmountOrdered, SUM(P.ListPrice) AS OrderRevenue FROM AdventureWorks2017.Production.WorkOrder WO JOIN AdventureWorks2017.Production.Product P ON WO.ProductID = P.ProductID GROUP BY [Name]";
            connection.Open();
            SqlCommand cmd = new SqlCommand(querylogic, connection);
            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            int row = 1;

            for (int i = 1; i <= dt.Columns.Count; i++)
            {
                xlWorkSheet.Cells[row, i] = dt.Columns[i - 1].ColumnName;
            }
            row++;
            foreach (DataRow dr in dt.Rows)
            {
                for (int i = 1; i <= dt.Columns.Count; i++)
                {

                    xlWorkSheet.Cells[row, i] = dr[i - 1].ToString();
                }
                row++;
            }
            notifyObservers();
        }

        public void registerObserver(Observer o)
        {
            observers.Add(o);
        }

        public void notifyObservers()
        {
            for (int i = 0; i < observers.Count; i++)
            {
                Observer observer = (Observer)observers[i];
                observer.update();
            }
        }
    }
}
