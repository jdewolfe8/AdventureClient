﻿using System.Windows;
using System.Windows.Controls;
using System.Data.SqlClient;
using AdventureClient.Factory;
using AdventureClient.ConcreteObservers;
namespace AdventureClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //RptFactory rf;
        int boxIndex;
        string makemessage;
        string numrows;
        string makeexcel;       
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var comboBox = sender as ComboBox;
            boxIndex = comboBox.SelectedIndex;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            switch (boxIndex)
            {
                case 0:
                    MessageBox.Show("Excel");
                    ReportFactory rf = new ReportFactory("sales", numrows, makemessage, makeexcel);
                    break;
                case 1:
                    MessageBox.Show("Message");
                    ReportFactory rf2 = new ReportFactory("workorder", numrows, makemessage, makeexcel);
                    break;
                case 2:
                    MessageBox.Show("Two");
                    break;
                default:
                    break;
            }
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            //CheckBox cb = sender as CheckBox;
            makemessage = "True";
        }

        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            //CheckBox cb = sender as CheckBox;
            makemessage = "False";

        }

        private void CheckBox_Checked_1(object sender, RoutedEventArgs e)
        {
            //CheckBox cb = sender as CheckBox;
            makeexcel = "True";

        }

        private void CheckBox_Unchecked_1(object sender, RoutedEventArgs e)
        { 
            makeexcel = "False";
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            numrows = tb.GetLineText(0);
        }
    }

}
