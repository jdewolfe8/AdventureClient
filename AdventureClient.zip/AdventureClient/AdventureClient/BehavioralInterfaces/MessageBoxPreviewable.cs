﻿namespace AdventureClient.BehavioralInterfaces
{
    interface MessageBoxPreviewable
    {
        void messagePreview();
    }
}
