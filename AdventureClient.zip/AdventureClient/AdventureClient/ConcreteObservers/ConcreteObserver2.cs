﻿using System.Net;
using System.Net.Mail;
using AdventureClient.ObserverInterfaces;
namespace AdventureClient.ConcreteObservers
{
    public class ConcreteObserver2 : Observer
    {
        private string emailaddress;
        private Subject reportdata;
        public ConcreteObserver2(Subject reportdata)
        {
            this.emailaddress = @"jdewolfe13@gmail.com";
            reportdata.registerObserver(this);
        }

        public void update()
        {
            sendemail();
        }

        private void sendemail()
        {
            SmtpClient MyServer = new SmtpClient();
            MyServer.Host = "";
            MyServer.Port = 81;
            NetworkCredential NC = new NetworkCredential();
            NC.UserName = "jdewolfe8@gmail.com";
            NC.Password = "dewolfe3";
            //assigned credetial details to server
            MyServer.Credentials = NC;

            //create sender address
            MailAddress from = new MailAddress("jdewolfe8@gmail.com", "James from");

            //create receiver address
            MailAddress receiver = new MailAddress("jdewolfe13@gmail.com", "James to");

            MailMessage Mymessage = new MailMessage(from, receiver);
            Mymessage.Subject = "subject";
            Mymessage.Body = "body";
            //sends the email
            //attachment stuff https://msdn.microsoft.com/en-us/library/system.net.mail.mailmessage(v=vs.110).aspx
            MyServer.Send(Mymessage);

        }



    }
}
