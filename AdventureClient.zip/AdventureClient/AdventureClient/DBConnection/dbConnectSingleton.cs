﻿using System.Data.SqlClient;

namespace AdventureClient.DBConnection
{
    public sealed class dbConnectSingleton
    {
        private static dbConnectSingleton instance = new dbConnectSingleton();
        private SqlConnection connection;
        static readonly object padlock = new object();

        private dbConnectSingleton()
        {
            connection = new SqlConnection(@"Server=DESKTOP-270VR6H;Database=AdventureWorks2017;Trusted_Connection=Yes;");
        }

        public static dbConnectSingleton Instance
        {
            get
            {
                lock (padlock)
                {
                    if (instance == null)
                    {
                        instance = new dbConnectSingleton();
                    }
                    return instance;
                }
            }
        }
    }
}
