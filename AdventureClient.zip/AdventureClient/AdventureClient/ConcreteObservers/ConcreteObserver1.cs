﻿using System.Net;
using System.Net.Mail;
using AdventureClient.ObserverInterfaces;
namespace AdventureClient.ConcreteObservers
{
    public class ConcreteObserver1 : Observer
    {
        MailAddress fromAddress = new MailAddress("from@gmail.com", "From Name");
        MailAddress toAddress = new MailAddress("to@example.com", "To Name");
        string fromPassword = "fromPassword";
        string subject = "Subject";
        string body = "Body";
        public ConcreteObserver1(Subject reportdata)
        {
            reportdata.registerObserver(this);
        }

        public void update()
        {
            sendemail();
        }

        private void sendemail()
        {
            SmtpClient MyServer = new SmtpClient();
            MyServer.Host = "smtp.gmail.com";
            MyServer.Port = 587;
            MyServer.EnableSsl = true;
            MyServer.DeliveryMethod = SmtpDeliveryMethod.Network;
            MyServer.UseDefaultCredentials = false;
            NetworkCredential NC = new NetworkCredential();
            NC.UserName = "jdewolfe8@gmail.com";
            NC.Password = "dewolfe3";
            MyServer.Credentials = NC;
            MailAddress from = new MailAddress("jdewolfe8@gmail.com", "James from");
            MailAddress receiver = new MailAddress("jdewolfe13@gmail.com", "James to");

            MailMessage Mymessage = new MailMessage(from, receiver);
            Mymessage.Subject = "subject";
            Mymessage.Body = "body";
            //attachment stuff https://msdn.microsoft.com/en-us/library/system.net.mail.mailmessage(v=vs.110).aspx
            MyServer.Send(Mymessage);
            
        }
    }
}