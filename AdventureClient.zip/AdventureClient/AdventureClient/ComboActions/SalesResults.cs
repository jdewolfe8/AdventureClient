﻿using System.Data;
using System.Data.SqlClient;
using System.Windows;
using AdventureClient.BehavioralInterfaces;
using Excel = Microsoft.Office.Interop.Excel;
using System.Collections;
using AdventureClient.ObserverInterfaces;
using AdventureClient.ConcreteObservers;
namespace AdventureClient.ComboActions
{
    public class SalesResults : MessageBoxPreviewable, ExcelReportable, Subject
    {
        private ArrayList observers;
        public string rownumbers;
        string connectionstring;
        public SalesResults(string rownumbers)
        {
            this.rownumbers = "TOP" + "(" + rownumbers + ") ";
            connectionstring = @"Server=DESKTOP-270VR6H;Database=AdventureWorks2017;Trusted_Connection=Yes;";
            observers = new ArrayList();
            ConcreteObserver1 co1 = new ConcreteObserver1(this);
        }
        public void messagePreview()
        {
            //perhaps can shrink combobox and put label above
            //salesorderheader table will provide sales totals by date
            SqlConnection connection = new SqlConnection(this.connectionstring);
            string querylogic = "SELECT " + this.rownumbers +"SP.FirstName+' '+SP.LastName as SalesPerson, ST.Name, CONVERT(money,SUM(SubTotal)) AS SubTotal FROM [AdventureWorks2017].[Sales].[SalesOrderHeader] SOH JOIN [AdventureWorks2017].[Person].[Person] SP ON SOH.SalesPersonID = SP.BusinessEntityID JOIN AdventureWorks2017.Sales.SalesTerritory ST ON SOH.TerritoryID = ST.TerritoryID WHERE SalesPersonID IS NOT NULL GROUP BY SP.FirstName+' '+SP.LastName, ST.[Name]";
            string queryOutput="";
            connection.Open();
            SqlCommand cmd = new SqlCommand(querylogic,connection);
            SqlDataReader reader = cmd.ExecuteReader();
            var dataTable = new DataTable();
            //field count and next result might make it easier to display everything
            while (reader.Read())
            {
                queryOutput = queryOutput + reader.GetValue(0) + '-' + reader.GetValue(1) + '\n';
            }
            MessageBox.Show(queryOutput);
        }

        public void generateExcelReport()
        {
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            xlApp.Visible = true;
            Excel.Workbook xlWorkBook = xlApp.Workbooks.Add();
            Excel.Worksheet xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
            //xlWorkSheet.Cells[1, 1] = "ID";
            SqlConnection connection = new SqlConnection(this.connectionstring);
            string querylogic = "SELECT SP.FirstName+' '+SP.LastName as SalesPerson, ST.Name, CONVERT(money,SUM(SubTotal)) AS SubTotal FROM [AdventureWorks2017].[Sales].[SalesOrderHeader] SOH JOIN [AdventureWorks2017].[Person].[Person] SP ON SOH.SalesPersonID = SP.BusinessEntityID JOIN AdventureWorks2017.Sales.SalesTerritory ST ON SOH.TerritoryID = ST.TerritoryID WHERE SalesPersonID IS NOT NULL GROUP BY SP.FirstName+' '+SP.LastName, ST.[Name]";
            connection.Open();
            SqlCommand cmd = new SqlCommand(querylogic, connection);
            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            int row = 1;

            for (int i = 1; i <= dt.Columns.Count; i++)
            {
                xlWorkSheet.Cells[row, i] = dt.Columns[i - 1].ColumnName;
            }
            row++;
            foreach (DataRow dr in dt.Rows)
            {
                for (int i = 1; i <= dt.Columns.Count; i++)
                {

                        xlWorkSheet.Cells[row, i] = dr[i - 1].ToString();
                }
                row++;
            }
            notifyObservers();
        }

        public void registerObserver(Observer o)
        {
            observers.Add(o);
        }

        public void notifyObservers()
        {
            for(int i = 0; i < observers.Count; i++)
            {
                Observer observer = (Observer)observers[i];
                observer.update();
            }
        }
    }
}
