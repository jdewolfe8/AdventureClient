﻿using AdventureClient.ComboActions;
using System.Windows;
namespace AdventureClient.Factory
{
    public class ReportFactory
    {
        public ReportFactory(string type, string numrows, string makemessage,string makeexcel)
        {
            switch (type+makemessage+makeexcel)
            {
                case "salesTrueTrue":
                    SalesResults sr = new SalesResults(numrows);
                    sr.messagePreview();
                    sr.generateExcelReport();
                    break;
                case "salesTrueFalse":
                    SalesResults sr2 = new SalesResults(numrows);
                    sr2.messagePreview();
                    break;
                case "salesFalseTrue":
                    SalesResults sr3 = new SalesResults(numrows);
                    sr3.generateExcelReport();
                    break;
                case "salesFalseFalse":
                    MessageBox.Show("No output selected");
                    break;
                case "workorderTrueTrue":
                    WorkOrderReport wo = new WorkOrderReport(numrows);
                    wo.messagePreview();
                    wo.generateExcelReport();
                    break;
            }
        }
    }
}
