﻿namespace AdventureClient.ObserverInterfaces
{
    public interface Observer
    {
        //could have a list of emails or a spreadsheet object that get updated
        //could have checkbox create spreadsheet and add to list of observers, somehow as a class? or class with a list property for the filepaths?
        void update();
    }
}
